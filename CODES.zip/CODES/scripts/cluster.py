#!/home/qnt/michalr/anaconda3/bin/python3.9

"""
this code classifies clusters acccording to their geometry.
n_res - num of differend molecules - from variable file (line 3)
"""

import numpy
from numpy import *
from sklearn.cluster import KMeans
from yellowbrick.cluster import KElbowVisualizer
from os.path import exists
import math
import os


# functions

def read_variables_file():
    """This function reads the file variables.txt and returns an array with the different variables"""
    # variables.txt
    temp_variables = open("vars/variables.txt", 'r')
    temp_variables = temp_variables.read().splitlines()
    temp_variables = [i.split(' ') for i in temp_variables]
    variables = []
    for line in range(1, len(temp_variables)):
        variables.append(temp_variables[line][0])  
    return variables


def read_file(path):
    """This function reads the file in PATH and splits it to lines"""
    file = open(path, 'r')
    f = file.read().splitlines()
    return f


def tot_center_of_mass(file_lines, x_line, y_line, z_line):
    """This function calculates the center of mass of the whole cluster"""
    x = file_lines[x_line]
    y = file_lines[y_line]
    z = file_lines[z_line]
    r = sqrt(x ** 2 + y ** 2 + z ** 2)
    return [x, y, z, r]


def vec_size(vec):
    x = vec[0]
    y = vec[1]
    z = vec[2]
    r = sqrt(x ** 2 + y ** 2 + z ** 2)
    return r
    

# settings
variables = read_variables_file()
cluster_name = variables[0]
n_res = eval(variables[2])

# code
directory = "geometries/txt"
files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]

# Descriptors
Ides = []  # 1
E = []
rdip = []  # 2
surf = []  # 3
n = []
cm = []  # 4
des = []

for txt_file in files:
    path = directory + "/" + txt_file
    f = read_file(path)
    for i in range(len(f)):
        f[i] = float(f[i])
    if not math.isnan(f[0]):
        E_i = round(f[0], 5)
        rdip_i = f[1]
        surf_i = f[2]
        I_i = f[3]
        # center of mass
        cm_i = []
        if n_res > 1:
            tot_cm_i = tot_center_of_mass(f, 4, 5, 6)  # for the whole cluster
            for res in range(1, n_res + 1):
                x_line = 4 + res*3
                y_line = 5 + res*3
                z_line = 6 + res*3
                seg_cm_i = tot_center_of_mass(f, x_line, y_line, z_line)
                rel_cm = numpy.array(tot_cm_i) - numpy.array(seg_cm_i)
                rel_cm_tot = vec_size(rel_cm)
                cm_i.append(rel_cm_tot)
            cm.append(cm_i)
        des_i = numpy.concatenate(([rdip_i, surf_i, I_i], cm_i))
        #if I_i < 50000:
        des.append(list(des_i))
        E.append(E_i)
        n.append(int(txt_file[0:-4]))

import pandas as pd
df = pd.DataFrame(E)
writer = pd.ExcelWriter('NOMC.xlsx', engine='xlsxwriter')
df.to_excel(writer, sheet_name='NOMC', index=False)
writer.close()
stop

# norm
des = numpy.array(des)
des = des.T

for i in range(len(des)):
    if (max(des[i]) - min(des[i])) != 0:
        des[i] = (des[i] - min(des[i]))/ (max(des[i]) - min(des[i]))

print("start clustering...")

# optimal k
des = des.T
model = KMeans()
max_k = len(n)
if max_k > 500:
    max_k = 500
v = KElbowVisualizer(model, k=(1, max_k), timings=False)
v.fit(des)

print("done calculate k-elbow")

# clustering
k_means = KMeans(n_clusters=v.elbow_value_)
k_means.fit(des)
y_kmeans = k_means.predict(des)

num_groups = len(numpy.unique(y_kmeans))

# choose 3 files from each group
groups = numpy.array([n, E, y_kmeans])
groups = groups.T
groups = list(groups)
groups.sort(key=lambda row: (row[2], row[1]))

# only clusters with different energy from the same group
ener = []
clust = []
new_groups = []
for cluster in groups:
    if cluster[1] not in ener or cluster[2] not in clust:
        new_groups.append(cluster)
        ener.append(cluster[1])
        clust.append(cluster[2])

groups = new_groups        
print(numpy.array(groups))

files_to_DFT = [] 
for group in range(num_groups):
    files_in_group = [f for f in groups if f[2] == group]
    files_in_group = numpy.array(files_in_group)
    l = len(files_in_group)
    if l > 2:
        files_to_DFT.append(int(files_in_group[0][0]))
        files_to_DFT.append(int(files_in_group[1][0]))
        files_to_DFT.append(int(files_in_group[2][0]))
    else:
        for ll in range(l):
            files_to_DFT.append(int(files_in_group[ll][0]))

# move all rellevant files to $cluster_name$ folder
os.system("mkdir results/{}".format(cluster_name))
os.system("wait")
new_indx = 1
for file_num in files_to_DFT: 
    file = "geometries/pdb/{}.pdb".format(str(file_num))
    os.system("cp {} ./results/{}/{}.pdb".format(file, cluster_name, str(new_indx)))
    new_indx += 1
    
# delete all irellevant files
#os.system("rm -f geometries/pdb/*")
#os.system("rm -f geometries/txt/*")

# convert to gjf
dir = "results/{}".format(cluster_name)
files = [f for f in os.listdir(dir) if os.path.isfile(os.path.join(dir, f))]
gaussian_input = read_file("vars/gaussian.txt")
for file in files:
  file_num = file[0:-4]
  os.system("babel -ipdb {}/{}.pdb -ogjf > {}/{}.gjf".format(dir, file_num, dir, file_num))
  os.system("wait")
  command = "sed -i 's/#Put Keywords Here, check Charge and Multiplicity./%chk={}.chk\\n%{}\\n%{}\\n#p {}/' {}/{}.gjf".format(file_num, gaussian_input[3], gaussian_input[4], gaussian_input[5], dir, file_num)
  os.system(command)
  os.system("sed -i '8s/0  .*/{}/g' {}/{}.gjf".format(gaussian_input[6], dir, file_num))

print('')
print("##############################")
print("# All done! Finished! YAY!!! #")
print("##############################")
print('')

