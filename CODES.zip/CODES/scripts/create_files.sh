#!/bin/sh
segname=$1

source /opt/intel/oneapi/setvars.sh
export UCX_TLS=ud,sm,self

~/charmm/c48a1_25122022_try/build/cmake/charmm segid=$segname < scripts/create_files.inp
