#!/home/qnt/michalr/anaconda3/bin/python3.9

import numpy as np
import os
import re
    
# create str and psf from xyz files
directory = "xyz"
files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]
for xyz_file in files:
    command_pdb = "scripts/xyz2pdb.csh {} {} {}".format(xyz_file[0:-4].lower(), xyz_file[0:-4].upper(), len(xyz_file[0:-4]))
    command_mol2 = "babel -ipdb pdb/{}.pdb -omol2 > str/{}.mol2".format(xyz_file[0:-4].lower(), xyz_file[0:-4].lower())
    command_str =  "/private/chem/silcsbio.2022.1/cgenff/cgenff str/{}.mol2 > str/{}.str".format(xyz_file[0:-4].lower(), xyz_file[0:-4].lower())
    command_str_correction = "sed -i \"s/pdb\/{}./{}/\" str/{}.str".format(xyz_file[0:-4].lower(), xyz_file[0:-4].upper(), xyz_file[0:-4].lower())
    command_psf = "scripts/create_files.sh {}".format(xyz_file[0:-4].upper())
    os.system(command_pdb)
    os.system("wait")
    
    pdb_file = open("pdb/{}.pdb".format(xyz_file[0:-4].lower()), "r")
    num_atoms = 0
    for word in pdb_file:
        if re.search("ATOM", word):
            num_atoms += 1
    # numbering the atoms in pdb file
    if num_atoms < 10:
        for line in range(num_atoms):
            os.system("sed -i \"{}s/./{}/15\" pdb/{}.pdb".format(str(line + 3), str(line + 1), xyz_file[0:-4].lower()))
    else:
        for line in range(9):
            os.system("sed -i \"{}s/./{}/15\" pdb/{}.pdb".format(str(line + 3), str(line + 1), xyz_file[0:-4].lower()))
        for line in range(9, num_atoms):
            os.system("sed -i \"{}s/./{}/15\" pdb/{}.pdb".format(str(line + 3), str(line + 1), xyz_file[0:-4].lower()))
            os.system("sed -i \"{}s/.//17\" pdb/{}.pdb".format(str(line + 3), xyz_file[0:-4].lower()))
    
    os.system("wait")    
    os.system(command_mol2)
    os.system("wait")
    os.system(command_str)
    os.system("wait")
    os.system(command_str_correction)
    os.system("wait")
    os.system(command_psf)
os.system("rm -f str/*.mol2")
    



















