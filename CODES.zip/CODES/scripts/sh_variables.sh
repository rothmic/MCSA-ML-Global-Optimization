#!/bin/sh
source /opt/intel/oneapi/setvars.sh
export UCX_TLS=ud,sm,self
