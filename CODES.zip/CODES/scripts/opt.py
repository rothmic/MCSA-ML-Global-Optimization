#!/home/qnt/michalr/anaconda3/bin/python3.9

import numpy as np
import os

def read_variables_file():
    """This function reads the files variables.txt, MCSAvars.txt and returns an array with the different variables"""
    # variables.txt
    temp_variables = open("vars/variables.txt", 'r')
    temp_variables = temp_variables.read().splitlines()
    temp_variables = [i.split(' ') for i in temp_variables]
    variables = []
    for line in range(2, len(temp_variables)):
        variables.append(temp_variables[line][0])
    # MCSAvars.txt
    temp_variables = open("vars/MCSAvars.txt", 'r')
    temp_variables = temp_variables.read().splitlines()
    temp_variables = [i.split(' ') for i in temp_variables]
    MCSAvars = []
    for line in range(1, len(temp_variables)):
        MCSAvars.append(temp_variables[line][0])    
    return variables, MCSAvars


def isprime(num):
    """This function check for prime numbers. return True if num is prime and False if not"""
    for i in range(2, num):
        if num % i == 0:
            return False
    return True


def define_symmetry(variables):
    """This function randomly chose a symmetry for the system, accordin to the symmetry workflow. 
    returns [vector of beasis molecules for each reduced group, vector of symmetry operations for each reduced group]"""
    N = int(variables[0])
    opt_file = "opt1.inp"
    if N == 1:  # homogeneous cluster
        segid = variables[1]
        n1 = int(variables[2])
        # initial state:
        p = np.random.randint(3)
        # check for prime number
        #if isprime(n1):
        #    n1 -= 1
        #    total_system_symmetries = [[1]]
        #    basis_species = [[segid, 1]]
        n1 -= p
        if p != 0:
          total_system_symmetries = [[1]]
          basis_species = [[segid, p]]
        else: 
          total_system_symmetries = []
          basis_species = []
        S = np.random.randint(n1) + 1  # Choose S
        while n1 % S != 0:
             S = np.random.randint(n1) + 1
        m = int(n1 / S)  # num molecules in S reduced groups
        for reduced_group in range(S):  # Define a set of rotation operators for each reduced group
            chi_S = np.random.randint(m) + 1
            while m % chi_S != 0:
                chi_S = np.random.randint(m) + 1
            b_S = int(m / chi_S)  # basis species
            basis_species.append([segid, b_S])
            symmetry_operators = []
            mult = 1
            chi_S_remainder = chi_S
            while mult != chi_S:
                rotation_operation = np.random.randint(chi_S_remainder) + 1
                if len(symmetry_operators) == 2:
                    rotation_operation = int(chi_S / mult)
                if chi_S_remainder % rotation_operation == 0 and rotation_operation != 1:
                    mult *= rotation_operation
                    chi_S_remainder /= rotation_operation
                    symmetry_operators.append(rotation_operation)
            if not symmetry_operators:  # if the list is empty (no symmetry)
                symmetry_operators.append(1)
            total_system_symmetries.append(symmetry_operators)
        return basis_species, total_system_symmetries, opt_file
    else:  # if N != 1
        n_s = []
        segids = []
        total_system_symmetries = []
        basis_species = []
        for n_i in range(N):
            n_s.append(int(variables[2 + 2 * n_i]))
            segids.append(variables[1 + 2 * n_i])
        S = min(n_s)    # define S = min(n_i)
        n_s = np.array(n_s)
        n_s_mod = n_s % S
        if sum(n_s_mod) == 0:    # n_i % S = 0 for all n_i
            if np.random.rand() < 0.1:   # look for random building as well. 10%
                for segid_i in range(N):
                    segid = segids[segid_i]
                    b_S = n_s[segid_i]
                    basis_species.append([segid, b_S])
                    total_system_symmetries.append([1])
                return basis_species, total_system_symmetries, opt_file
            opt_file = "opt2.inp"
            for segid_i in range(N):  # Define a set of rotation operators for each segid type
                m = n_s[segid_i] / S            
                segid = segids[segid_i]
                chi_S = np.random.randint(m) + 1
                while m % chi_S != 0:
                    chi_S = np.random.randint(m) + 1
                b_S = int(m / chi_S)  # basis species
                basis_species.append([segid, b_S])
                symmetry_operators = []
                mult = 1
                chi_S_remainder = chi_S
                while mult != chi_S:
                    rotation_operation = np.random.randint(chi_S_remainder) + 1
                    if len(symmetry_operators) == 2:
                        rotation_operation = int(chi_S / mult)
                    if chi_S_remainder % rotation_operation == 0 and rotation_operation != 1:
                        mult *= rotation_operation
                        chi_S_remainder /= rotation_operation
                        symmetry_operators.append(rotation_operation)
                if S != 1:
                    symmetry_operators.append(S)
                if not symmetry_operators:  # if the list is empty (no symmetry)
                    symmetry_operators.append(1)
                total_system_symmetries.append(symmetry_operators)
            return basis_species, total_system_symmetries, opt_file
        else:                    # n_i % S != 0 for all n_i
            for segid_i in range(N):  # Define a set of rotation operators for each segid type
                m = n_s[segid_i]
                segid = segids[segid_i]
                chi_S = np.random.randint(m) + 1
                while m % chi_S != 0:
                    chi_S = np.random.randint(m) + 1
                b_S = int(m / chi_S)  # basis species
                basis_species.append([segid, b_S])
                symmetry_operators = []
                mult = 1
                chi_S_remainder = chi_S
                while mult != chi_S:
                    rotation_operation = np.random.randint(chi_S_remainder) + 1
                    if len(symmetry_operators) == 2:
                        rotation_operation = int(chi_S / mult)
                    if chi_S_remainder % rotation_operation == 0 and rotation_operation != 1:
                        mult *= rotation_operation
                        chi_S_remainder /= rotation_operation
                        symmetry_operators.append(rotation_operation)
                if not symmetry_operators:  # if the list is empty (no symmetry)
                    symmetry_operators.append(1)
                total_system_symmetries.append(symmetry_operators)
            return basis_species, total_system_symmetries, opt_file

    

def save_files_for_charmm(basis_species, total_system_symmetries):
    """This function saves files in order to read the parameters into charmm. The function will save one file for each reduced group"""
    for unit in range(len(basis_species)):
        file_name = "fort." + str(unit + 10)
        file_to_write = open(file_name, "w")
        file_to_write.write(basis_species[unit][0] + "\n")
        file_to_write = open(file_name, "a")
        file_to_write.write(str(basis_species[unit][1]) + "\n")
        file_to_write.write(str(len(total_system_symmetries[unit])) + "\n")
        for symmetry_operations in total_system_symmetries[unit]:
            file_to_write.write(str(symmetry_operations) + "\n")


# main
variables, MCSAvars = read_variables_file()
iterations = int(variables[0])
variables.pop(0)

for iteration in range(1, iterations + 1): 
  basis_species, total_system_symmetries, opt_file = define_symmetry(variables)
  print(iteration, basis_species, total_system_symmetries)
  save_files_for_charmm(basis_species, total_system_symmetries)
  
  num_units = len(basis_species) + 9
  os.system(f"~/charmm/c48a1_25122022_try/build/cmake/charmm k={iteration} q={num_units} Tii={MCSAvars[0]} Tff={MCSAvars[1]} kk={MCSAvars[2]} NStep={MCSAvars[3]} < scripts/{opt_file} > temp.out")
  os.system("wait")
  os.system("rm -f fort.*")
  #os.system("rm -f temp.out")
  os.system("wait")



















