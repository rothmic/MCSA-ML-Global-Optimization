--------------------------------------------------------------------------
-     This file contains work steps to setup the needed environment.     -
- Possible changes in the different parameters are described in the end. -
-                    Last modification in 14.03.2023                     -
--------------------------------------------------------------------------

BEFORE YOU START: 
   ---------------------------------------------------------------------------------------------------------
set your CHARMM environment! - in the file source/manip/rgyr.F90 add in the section with the title:
"SUBROUTINE LSQP(N,X,Y,Z,W,AMASS,ISLCT,LVERB,LMASS,LWEIG,QAXIS)"
1. ITOT --> at the end of real(chm_real) line, which defines the variables XX,YY,ZZ, etc. (c48a1 - in line 260)
2. ITOT=XX+YY+ZZ --> (c48a1 - in line 310)
3. call set_param('ITOT',ITOT) --> (c48a1 - in line 311)
   ---------------------------------------------------------------------------------------------------------
set your python environment! - in all the .py codes, set the environment (first line) to your path
   ---------------------------------------------------------------------------------------------------------
make sure you have cgenFF and obabel softwares. define their path in:
1. "create_files.py" in lines 12 and 13.
2. "scripts/xyz2pdb.csh" line 5
3. "cluster.py" line 173
--------------------------------------------------------------------------------------------------------------------------

WORK STEPS:
1. save an xyz files of the molecules and ions in the cluster. in the xyz directory. name the file as in CGenFF if exists - ###.xyz
2. run "create_files.py" - for un-usual charge change the charges manualy on the suitable str file in the str dir.
    For elments which does not supportet by CGenFF, create str file by hand, save it in the str directory and run "create_files_no_str.py"
    Check the crd files - if there are missing coordinates, check the atoms names in your str file, and match it the pdb file 
    and run the script again. 
3. create a "variables.txt" file and save it in the "vars" dir. This file contains the data on your cluster.
	Format:
	#1: Title
	#2: Cluster's name
	#3: num iterations - different geometries to generate
	#4: num types of molecules
	#5: name of first molecule (the same as the xyz file name)
	#6: number of first molecule
	#7: name of first molecule
	#8: number of first molecule
	etc.
	* keep a space before any remark
4. edit the "MCSAvars.txt" file and save it in the "vars" dir. This file contains the data on your MCSA process.
	The SA process starts with temperature Ti and cools to Tf with a rate k [T{step} = Ti * e^(-k*step)].
	At each temperature there is MC process with Nstep steps.
	Format:
	#1: Title
	#2: Initial temperature (Ti)
	#3: Final temperature (Tf)
	#4: colling rate (k)
	#5: Nsteps
	* keep a space before any remark
4. edit the "gaussian.txt" file in the "vars" dir. This file contains the data on your DFT job.
	Format:
	#1: Title
	#2: notes
	#3: blank line
	#4: "mem=$$$" - edit only the $$$. default is 16GB.
	#5: "nprocshared=$$$" - edit only the $$$. default is 8.
	#6: the job type you want (all the data comes after the #P in gaussian input file). 
		make sure to use back-slesh (\) before special characters.
	#7: charge and multiplicity
5. run opt.csh

--------------------------------------------------------------------------------------------------------------------------

changes:
# if you want to change the size of random translation for the initial structure - change the fact variable in line 98
# if you want to change the NOE setup - change in opt.inp, lines 187 - 188
# if you want to change the MCSA variables - change only(!) in opt.inp, lines 195 - 200 and lines 225 - 227
# if you want to change nbonds parameters in charmm - change in opt.inp, lines 165 - 167
# if you want to change the precentage of randon structure (of heterogeneous structures, with some S > 1) change the if statement
	in opt.py line 86.
 
 
